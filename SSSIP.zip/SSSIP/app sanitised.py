from flask import Flask, jsonify, request, send_from_directory, redirect, url_for, session
from flask_oidc import OpenIDConnect
import requests
import os

# Initialize the Flask application
app = Flask(__name__, static_url_path='')

# Configuration settings for the Flask application and OIDC
app.config.update({
    'OIDC_CLIENT_SECRETS': 'client_secrets.json',  # Configuration file for OIDC client
    'OIDC_ID_TOKEN_COOKIE_SECURE': False,  # Should be set to True for production
    'OIDC_OPENID_REALM': 'your_realm',  # The OIDC realm. Replace with your specific realm
    'SECRET_KEY': 'your_secret_key',  # A random secret string for session management
    'OIDC_COOKIE_SECURE': False,  # Should be set to True if using HTTPS
    'OIDC_CALLBACK_ROUTE': '/oidc-callback',  # The OIDC callback route
    'DEBUG': True,  # Set to False for production
})

# Initialize the OpenID Connect extension
oidc = OpenIDConnect(app)

# JumpCloud API key for authenticating API requests
JUMP_CLOUD_API_KEY = 'your_jumpcloud_api_key'

# Base URL for JumpCloud API
JUMPCLOUD_BASE_URL = 'https://console.jumpcloud.com/api/'

# Define the route for the index page
@app.route('/')
def index():
    if not oidc.user_loggedin:
        return redirect(url_for('login'))
    return send_from_directory(os.getcwd(), 'index.html')

@app.route('/api/apps', methods=['GET'])
@oidc.require_login
def apps():
    package_manager_filter = request.args.get('packageManager')
    
    url = JUMPCLOUD_BASE_URL + 'v2/softwareapps'
    headers = {'x-api-key': JUMP_CLOUD_API_KEY}
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Error: Unable to fetch software apps from JumpCloud. Status code: {response.status_code}, Response: {response.text}")
        return jsonify([])

    apps = response.json()
    if package_manager_filter:
        apps = [app for app in apps if app['settings'][0]['packageManager'] == package_manager_filter]
    
    return jsonify(apps)

@app.route('/api/devices', methods=['GET'])
@oidc.require_login
def devices():
    user_info = session['oidc_auth_profile']
    user_id = user_info.get('sub')
    devices = get_user_devices(user_id)
    return jsonify(devices)

def get_user_devices(user_id):
    url = JUMPCLOUD_BASE_URL + f'v2/users/{user_id}/systems'
    headers = {'x-api-key': JUMP_CLOUD_API_KEY}
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        print(f"Error: Unable to fetch devices for user {user_id} from JumpCloud. Status code: {response.status_code}, Response: {response.text}")
        return []

    device_ids = [device['id'] for device in response.json()]
    devices_details = []
    for device_id in device_ids:
        url = JUMPCLOUD_BASE_URL + f'systems/{device_id}'
        device_response = requests.get(url, headers=headers)
        if device_response.status_code != 200:
            print(f"Error: Unable to fetch details for device {device_id} from JumpCloud. Status code: {device_response.status_code}, Response: {device_response.text}")
            continue
        device_data = device_response.json()
        devices_details.append({
            'id': device_id, 
            'name': device_data.get('displayName', 'Unknown'), 
            'os': device_data.get('os', 'Unknown'),
            'active': device_data.get('active', 'Unknown'),
            'arch': device_data.get('arch', 'Unknown'),
            'archFamily': device_data.get('archFamily', 'Unknown'),
            'osFamily': device_data.get('osFamily', 'Unknown')
        })
    return devices_details

@app.route('/api/install', methods=['POST'])
@oidc.require_login
def install():
    data = request.json
    app_id = data['appId']
    device_id = data['deviceId']
    url = JUMPCLOUD_BASE_URL + f'v2/softwareapps/{app_id}/associations'
    headers = {'x-api-key': JUMP_CLOUD_API_KEY, 'Content-Type': 'application/json'}
    payload = {'op': 'add', 'type': 'system', 'id': device_id}
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        print(f"Error: Unable to initiate software installation on device {device_id}. Status code: {response.status_code}, Response: {response.text}")
        return jsonify({'status': 'Failed'})
    return jsonify({'status': 'Initiated'})

@app.route('/login')
@oidc.require_login
def login():
    return redirect(url_for('index'))

@app.route('/logout', methods=['GET'])
def logout():
    oidc.logout()
    return redirect(url_for('index'))

@app.route('/oidc-callback', methods=['GET', 'POST'])
@oidc.require_login
def oidc_callback():
    return redirect(url_for('index'))

@app.route('/profile')
@oidc.require_login
def profile():
    user_info = session['oidc_auth_profile']
    user_id = user_info.get('sub')
    name = user_info.get('name')
    email = user_info.get('email')
    return f'User ID: {user_id}, Name: {name}, Email: {email}'

@app.route('/api/user-info', methods=['GET'])
@oidc.require_login
def user_info():
    user_info = session['oidc_auth_profile']
    return jsonify(user_info)

if __name__ == '__main__':
    app.run(debug=True)
